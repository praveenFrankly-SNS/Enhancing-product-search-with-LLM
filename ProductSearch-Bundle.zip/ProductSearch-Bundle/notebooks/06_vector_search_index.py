# Databricks notebook source
# MAGIC %md
# MAGIC # Vector Search — Endpoint & Delta Sync Index Setup
# MAGIC **Responsibility**: Creates the Databricks Vector Search endpoint and the
# MAGIC Delta Sync index on `gold.product_search_catalog`, completing Pipeline 1
# MAGIC (Product Indexing Pipeline).
# MAGIC
# MAGIC ## Architecture — Option A (Databricks-Managed Embeddings)
# MAGIC
# MAGIC ```text
# MAGIC Gold Product Catalog  (searchable_text column)
# MAGIC           ↓
# MAGIC  Vector Search Delta Sync Index
# MAGIC           ↓
# MAGIC  Automatic Embedding Generation
# MAGIC  (BGE endpoint, managed by Databricks)
# MAGIC ```
# MAGIC
# MAGIC The index reads `searchable_text` from the Gold table, calls the BGE embedding
# MAGIC endpoint automatically, stores the vectors, and stays in sync via Change Data Feed.
# MAGIC No separate embedding generation step is needed.
# MAGIC
# MAGIC **Pipeline position (Offline — Product Indexing Pipeline — final step):**
# MAGIC ```
# MAGIC PostgreSQL → Bronze → Silver → Gold → CDF Prep → [THIS NOTEBOOK]
# MAGIC ```
# MAGIC
# MAGIC %pip install databricks-vectorsearch pyyaml
# COMMAND ----------
import sys
import time
import uuid
from pathlib import Path
from pyspark.sql import SparkSession

# Add project root to sys.path
try:
    notebook_path = dbutils.notebook.entry_point.getDbutils().notebook().getContext().notebookPath().get()
    project_root = "/Workspace" + notebook_path.split("/notebooks/")[0]
    if project_root not in sys.path:
        sys.path.insert(0, project_root)
except Exception:
    try:
        sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
    except NameError:
        pass

from databricks.vector_search.client import VectorSearchClient

from src.shared.config import get_config
from src.shared.constants import (
    GOLD, OPERATIONS,
    VECTOR_SEARCH_ENDPOINT_NAME,
    VECTOR_SEARCH_INDEX_NAME,
    EMBEDDING_MODEL_ENDPOINT,
)
from src.shared.logger import get_logger
from src.search.vector_index import (
    get_or_create_vs_endpoint,
    get_or_create_delta_sync_index,
    wait_for_index_online,
)

# Import monitoring telemetry
from src.monitoring.telemetry import record_metric

# Import governance package utilities
from src.governance import (
    validate_pipeline_config,
    verify_secrets_prerequisites,
    verify_catalog_prerequisites,
    record_pipeline_audit
)


# COMMAND ----------
spark = SparkSession.builder.getOrCreate()
logger = get_logger("vector_search_index")
# COMMAND ----------
# MAGIC %md
# MAGIC ### Configuration Widgets
# COMMAND ----------
dbutils.widgets.text("catalog",          "product_search_dev",          "Catalog Name")
dbutils.widgets.text("environment",      "dev",                         "Environment (dev/staging/prod)")
dbutils.widgets.text("vs_endpoint",      VECTOR_SEARCH_ENDPOINT_NAME,   "Vector Search Endpoint Name")
dbutils.widgets.text("pipeline_type",    "TRIGGERED",                   "Pipeline Type (TRIGGERED / CONTINUOUS)")
dbutils.widgets.text("wait_for_online",  "true",                        "Wait for Index Online? (true/false)")

config          = get_config(dbutils)
catalog         = config.catalog
vs_endpoint     = dbutils.widgets.get("vs_endpoint").strip()
pipeline_type   = dbutils.widgets.get("pipeline_type").strip().upper()
wait_for_online = dbutils.widgets.get("wait_for_online").strip().lower() == "true"
run_id          = str(uuid.uuid4())

# ── Enterprise Governance pre-execution validation checks ──────────────
# 1. Run config validation
config_check = validate_pipeline_config(config.yaml_config)
if not config_check["valid"]:
    raise RuntimeError(f"Governance Configuration check failed: {'; '.join(config_check['errors'])}")

# 2. Run secrets validation (this stage does not require database connection secrets)
governance_cfg = config.yaml_config.get("governance", {})
secrets_cfg = governance_cfg.get("secrets", {})
secret_scope = secrets_cfg.get("scope", config.yaml_config.get("pipeline", {}).get("secret_scope", ""))
required_secrets = []
secrets_check = verify_secrets_prerequisites(dbutils, secret_scope, required_secrets)
if not secrets_check["scope_exists"] or secrets_check["missing_keys"]:
    raise RuntimeError(f"Governance Secrets check failed in scope '{secret_scope}': {'; '.join(secrets_check['errors'])}")


# 3. Run catalog validation
catalog_check = verify_catalog_prerequisites(spark, catalog)
if not catalog_check["catalog_exists"] or catalog_check["errors"]:
    raise RuntimeError(f"Governance Catalog check failed on '{catalog}': {'; '.join(catalog_check['errors'])}")

# 4. Log successful validation
record_pipeline_audit(spark, catalog, run_id, "Vector Search", "pre_execution_governance_validation", "SUCCESS", "All governance prerequisites verified successfully.")

# Fully qualified names
source_table = f"{catalog}.{GOLD}.product_search_catalog"
index_name   = f"{catalog}.{GOLD}.{VECTOR_SEARCH_INDEX_NAME}"

logger.info(
    f"Vector Search setup starting (Run ID: {run_id})\n"
    f"  Endpoint:     {vs_endpoint}\n"
    f"  Source table: {source_table}\n"
    f"  Index name:   {index_name}\n"
    f"  Pipeline:     {pipeline_type}\n"
    f"  Embedding:    {EMBEDDING_MODEL_ENDPOINT}"
)
# COMMAND ----------
# MAGIC %md
# MAGIC ### 1. Create / Verify Vector Search Endpoint
# MAGIC
# MAGIC An endpoint must exist before creating an index. If it already exists, this step is a no-op.
# COMMAND ----------
t_start = time.time()

workspace_url = spark.conf.get("spark.databricks.workspaceUrl", "")
if not workspace_url.startswith("http"):
    workspace_url = f"https://{workspace_url}"

logger.info(f"Connecting to Vector Search at workspace: {workspace_url}")

# The VectorSearchClient picks up workspace URL and token automatically
# from the Databricks notebook environment
vsc = VectorSearchClient()

endpoint = get_or_create_vs_endpoint(vsc, vs_endpoint)
logger.info(f"Vector Search endpoint '{vs_endpoint}' is ready.")
print(f"✓ Endpoint '{vs_endpoint}' state: {endpoint.get('endpoint_status', {}).get('state', 'UNKNOWN')}")
# COMMAND ----------
# MAGIC %md
# MAGIC ### 2. Create Delta Sync Index
# MAGIC
# MAGIC The Delta Sync index watches `gold.product_search_catalog.searchable_text`,
# MAGIC automatically generates BGE embeddings for every row, and keeps vectors
# MAGIC in sync as products are added or updated (via CDF).
# MAGIC
# MAGIC **No separate embedding generation notebook is needed.**
# COMMAND ----------
# ── Step 1: Schema normalization for Vector Search compatibility ───────────
# Databricks Vector Search rejects: VARCHAR/CHAR (use STRING) and DECIMAL (use DOUBLE).
#
# Detection strategy (two-pronged):
#   • VARCHAR/CHAR: Spark's schema API normalizes these to StringType (invisible
#     via dtypes). Must parse the physical DDL from SHOW CREATE TABLE.
#   • DECIMAL: Detectable via Spark schema API (DecimalType). Spark does NOT
#     hide this — but it IS rejected by Vector Search.
#
# Fix: detect ALL affected columns, cast them, rewrite once with
#      CREATE OR REPLACE TABLE (which stamps the new physical schema).

import pyspark.sql.functions as F_vs
from pyspark.sql.types import DecimalType

# -- 1a. Detect VARCHAR / CHAR columns via physical DDL --------------------
_ddl_rows = spark.sql(f"SHOW CREATE TABLE {source_table}").collect()
_ddl_text  = _ddl_rows[0][0] if _ddl_rows else ""
_has_char  = "varchar" in _ddl_text.lower() or "char(" in _ddl_text.lower()

# -- 1b. Detect DECIMAL columns via Spark schema --------------------------
_schema       = spark.table(source_table).schema
_decimal_cols = [f.name for f in _schema.fields if isinstance(f.dataType, DecimalType)]

_needs_rewrite = _has_char or bool(_decimal_cols)

if _needs_rewrite:
    logger.info(
        f"Schema normalization required — "
        f"VARCHAR/CHAR in DDL: {_has_char}, DECIMAL columns: {_decimal_cols}. "
        f"Rewriting table with Vector Search-compatible types..."
    )
    _df = spark.table(source_table)

    # Cast DECIMAL → DOUBLE for all detected decimal columns
    for _col_name in _decimal_cols:
        _df = _df.withColumn(_col_name, F_vs.col(_col_name).cast("double"))
        logger.info(f"  Cast '{_col_name}': DECIMAL → double")

    # If any VARCHAR/CHAR present, cast ALL string columns to plain STRING.
    # We re-cast product_id unconditionally since it's the primary key.
    if _has_char:
        _df = _df.withColumn("product_id", F_vs.col("product_id").cast("string"))
        logger.info("  Cast 'product_id': VARCHAR → string")

    _df.createOrReplaceTempView("_product_catalog_tmp")
    spark.sql(f"""
        CREATE OR REPLACE TABLE {source_table}
        TBLPROPERTIES (delta.enableChangeDataFeed = true)
        AS SELECT * FROM _product_catalog_tmp
    """)
    spark.catalog.dropTempView("_product_catalog_tmp")
    logger.info("Schema normalization complete — table rewritten and CDF enabled.")
else:
    logger.info("Schema already Vector Search-compatible — no rewrite needed.")
    spark.sql(f"ALTER TABLE {source_table} SET TBLPROPERTIES (delta.enableChangeDataFeed = true)")




logger.info(f"Creating Delta Sync index '{index_name}' on source table '{source_table}'...")

index = get_or_create_delta_sync_index(
    client=vsc,
    endpoint_name=vs_endpoint,
    index_name=index_name,
    source_table_name=source_table,
    pipeline_type=pipeline_type,
    primary_key="product_id",
    embedding_source_column="searchable_text",
    embedding_model_endpoint_name=EMBEDDING_MODEL_ENDPOINT,
)

logger.info(f"Delta Sync index creation initiated for '{index_name}'.")
print(f"✓ Index '{index_name}' created/verified.")
# COMMAND ----------
# MAGIC %md
# MAGIC ### 3. Wait for Index to Come Online
# MAGIC
# MAGIC On initial creation, the index must process all 42,994 products and generate
# MAGIC embeddings before it is ready for queries. This typically takes 5–15 minutes.
# MAGIC
# MAGIC For subsequent syncs after catalog refreshes, only changed rows are re-processed.
# COMMAND ----------
if wait_for_online:
    logger.info("Waiting for index to reach ONLINE state (this may take 10–20 minutes on first run)...")
    index = wait_for_index_online(
        client=vsc,
        endpoint_name=vs_endpoint,
        index_name=index_name,
        timeout_minutes=30,
        poll_interval_seconds=30,
    )
    print(f"✓ Index '{index_name}' is ONLINE and ready for queries.")
else:
    print(
        f"ℹ Index '{index_name}' creation triggered. Set wait_for_online=true to poll for completion."
    )
# COMMAND ----------
# MAGIC %md
# MAGIC ### 4. Verify Index — Run a Quick Test Query
# COMMAND ----------
if wait_for_online:
    logger.info("Running verification query against the new index...")
    test_query = "comfortable ergonomic office chair"

    vs_index = vsc.get_index(endpoint_name=vs_endpoint, index_name=index_name)
    test_results = vs_index.similarity_search(
        query_text=test_query,
        query_type="HYBRID",
        columns=["product_id", "product_name", "category_path", "brand_name"],
        num_results=5,
    )

    result_rows = test_results.get("result", {}).get("data_array", [])
    col_names   = [c["name"] for c in test_results.get("result", {}).get("manifest", {}).get("columns", [])]

    print(f"\nTest query: '{test_query}'")
    print(f"Results returned: {len(result_rows)}")
    for row in result_rows:
        row_dict = dict(zip(col_names, row))
        print(f"  - [{row_dict.get('product_id')}] {row_dict.get('product_name')} | {row_dict.get('category_path')}")
# COMMAND ----------
duration = time.time() - t_start

logger.log_execution(
    spark=spark,
    catalog=catalog,
    task_name="vector_search_index",
    table_name=index_name,
    status="SUCCESS",
    rows_processed=0,
    duration_seconds=duration,
    message=f"Delta Sync index '{index_name}' on endpoint '{vs_endpoint}' created successfully.",
)

# Log telemetry operational metrics
record_metric(spark, catalog, "Vector Search", "vector_index_sync_duration", duration, "seconds", "SUCCESS")

# Record audit log
record_pipeline_audit(spark, catalog, run_id, "Vector Search", "vector_search_index_pipeline", "SUCCESS", f"Vector Search Index Delta sync completed successfully on endpoint '{vs_endpoint}'.")
logger.success(
    f"Vector Search setup complete. Index '{index_name}' is ready for hybrid semantic search."
)

